export const setErrorsProy = (nombreProyecto, descripcionProyecto, objetivoGeneral, objetivosEspecificos, estado, fase, presupuesto) => {
    let errors ={};
    //descrip,valUnit,estado  setErrorsProd
    /* errors.descrip = descrip?"":"descrip es requerido"
    errors.valUnit = valUnit?"":"valUnit es requerido"
    errors.estado = estado?"":"estado es requerido" */

    return errors
}

